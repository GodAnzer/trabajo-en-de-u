# Vitrina Rural Plus

Proyecto web avanzado, visual y totalmente editable para estudiantes que necesitan practicar **modificación de páginas existentes, personalización visual, ajuste de scripts y pruebas funcionales**.

## Objetivo
Este proyecto fue creado para que el estudiante pueda:
- abrir una base real en Visual Studio Code;
- entender su estructura;
- modificar contenido, estilos y funciones;
- realizar pruebas;
- corregir errores;
- y subir el resultado a GitHub como pieza de portafolio.

## Tecnologías
- HTML5
- CSS3
- JavaScript ES Modules

## Funcionalidades destacadas
- navegación responsive;
- buscador dinámico;
- filtros por categoría;
- tarjetas renderizadas con JavaScript;
- modal con detalle de cada iniciativa;
- contadores animados;
- formulario con validación;
- estructura lista para repositorio profesional.

## Estructura del proyecto
```bash
vitrina-rural-pro-max/
├── index.html
├── README.md
├── css/
│   └── styles.css
├── js/
│   └── app.js
├── data/
│   └── catalog.js
├── img/
│   ├── hero-illustration.svg
│   ├── item-cafe.svg
│   ├── item-ruta.svg
│   ├── item-mercado.svg
│   ├── item-diseno.svg
│   ├── item-huerta.svg
│   └── item-festival.svg
├── docs/
│   └── guia-mejoras.md
└── evidencias/
    └── .gitkeep
```

## Cómo ejecutar
1. Descomprime la carpeta.
2. Ábrela en Visual Studio Code.
3. Ejecuta `index.html` con Live Server o ábrelo directamente en el navegador.

## Ideas de personalización
- cambiar el tema a restaurante, cafetería, feria, tienda o institución;
- reemplazar imágenes y textos;
- agregar nuevas tarjetas en `data/catalog.js`;
- ajustar colores globales en `:root` dentro de `styles.css`;
- cambiar reglas del formulario en `app.js`.

## Recomendación para portafolio
Cuando subas este proyecto a GitHub, agrega:
- capturas de pantalla;
- explicación de qué cambiaste;
- nombres de autores;
- mejoras futuras.

## Autoría sugerida
- Nombre del estudiante 1
- Nombre del estudiante 2
