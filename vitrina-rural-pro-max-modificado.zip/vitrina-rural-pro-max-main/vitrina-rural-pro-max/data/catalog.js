export const catalog = [
  {
    id: 1,
    title: "Café de origen serrano",
    category: "productos",
    location: "Vereda La Esperanza",
    description: "Lote artesanal tostado en pequeñas cantidades, ideal para vitrinas locales y catálogos de emprendimiento.",
    tags: ["café", "artesanal", "portafolio"],
    image: "img/item-cafe.svg"
  },
  {
    id: 2,
    title: "Ruta ecológica guiada",
    category: "servicios",
    location: "Sendero Alto Verde",
    description: "Experiencia turística con acompañamiento local, pensada para promocionar territorio y cultura comunitaria.",
    tags: ["turismo", "guía", "naturaleza"],
    image: "img/item-ruta.svg"
  },
  {
    id: 3,
    title: "Mercado campesino semanal",
    category: "eventos",
    location: "Parque central",
    description: "Espacio de encuentro para productores, estudiantes y visitantes, con exhibición de alimentos y artesanías.",
    tags: ["mercado", "evento", "comunidad"],
    image: "img/item-mercado.svg"
  },
  {
    id: 4,
    title: "Diseño de marca para emprendedores",
    category: "servicios",
    location: "Aula digital",
    description: "Servicio de acompañamiento básico para identidad visual, piezas promocionales y contenido web.",
    tags: ["branding", "diseño", "emprendimiento"],
    image: "img/item-diseno.svg"
  },
  {
    id: 5,
    title: "Huerta escolar demostrativa",
    category: "productos",
    location: "Institución educativa",
    description: "Proyecto pedagógico con producción local, aprendizaje ambiental y posibilidad de difusión digital.",
    tags: ["huerta", "escuela", "sostenible"],
    image: "img/item-huerta.svg"
  },
  {
    id: 6,
    title: "Festival cultural de la montaña",
    category: "eventos",
    location: "Casa de la cultura",
    description: "Actividad para promover danza, música, gastronomía y participación juvenil mediante una web atractiva.",
    tags: ["cultura", "festival", "juventud"],
    image: "img/item-festival.svg"
  }
,
  {
    id: 7,
    title: "Café Premium Exportación",
    category: "cafes",
    location: "Medellín",
    description: "Café especial cultivado y seleccionado para exportación.",
    tags: ["premium","café"],
    image: "img/item-cafe.svg"
  }

];