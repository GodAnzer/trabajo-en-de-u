# Guía de mejoras y estudio

## Qué revisar primero
1. Abre `index.html` y reconoce la estructura general.
2. Observa cómo `styles.css` controla colores, tarjetas, botones y diseño responsive.
3. Revisa `app.js` para entender los filtros, el modal y el formulario.
4. Mira `data/catalog.js` para identificar de dónde salen las tarjetas del catálogo.

## Cambios recomendados para sorprender en la entrega
- Crear una nueva categoría y agregar más tarjetas.
- Cambiar completamente el enfoque del proyecto: por ejemplo, a cafetería o restaurante.
- Personalizar la sección de agenda con eventos reales.
- Mejorar el formulario para que recoja datos más acordes al proyecto.
- Cambiar la paleta de colores y la tipografía visual.
- Agregar más indicadores en el bloque de estadísticas.

## Evidencias sugeridas
- captura de la página principal;
- captura del catálogo filtrado;
- captura del formulario funcionando;
- captura de la consola sin errores.

## Checklist técnico
- [ ] El sitio abre sin errores visuales graves.
- [ ] El menú responsive funciona.
- [ ] El buscador sí filtra tarjetas.
- [ ] El modal muestra información correcta.
- [ ] El formulario valida datos.
- [ ] La consola no muestra errores de JavaScript.
- [ ] El README fue editado por el estudiante.

## Ideas de mejora profesional
- agregar modo oscuro/claro;
- guardar favoritos con localStorage;
- crear una segunda página `detalle.html`;
- integrar un carrusel;
- conectar el formulario con Firebase en una versión futura.
