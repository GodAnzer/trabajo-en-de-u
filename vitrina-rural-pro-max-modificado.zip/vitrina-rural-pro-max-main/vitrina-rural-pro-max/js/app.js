import { catalog } from "../data/catalog.js";

const cardsGrid = document.getElementById("cardsGrid");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const chipContainer = document.getElementById("chipContainer");
const emptyState = document.getElementById("emptyState");
const detailModal = document.getElementById("detailModal");
const modalContent = document.getElementById("modalContent");
const closeModal = document.getElementById("closeModal");
const navToggle = document.getElementById("navToggle");
const mainNav = document.getElementById("mainNav");
const contactForm = document.getElementById("contactForm");
const formSuccess = document.getElementById("formSuccess");

const statProducts = document.getElementById("statProducts");
const statCategories = document.getElementById("statCategories");

let activeCategory = "all";
let searchTerm = "";

function init() {
  populateStats();
  renderFilters();
  renderCards(catalog);
  setupEvents();
  animateCounters();
}

function populateStats() {
  const categories = new Set(catalog.map((item) => item.category));
  statProducts.textContent = String(catalog.length);
  statCategories.textContent = String(categories.size);
}

function renderFilters() {
  const categories = ["all", ...new Set(catalog.map((item) => item.category))];

  categoryFilter.innerHTML = categories
    .map((category) => {
      const label = category === "all" ? "Todas las categorías" : capitalize(category);
      return `<option value="${category}">${label}</option>`;
    })
    .join("");

  chipContainer.innerHTML = categories
    .map((category) => {
      const label = category === "all" ? "Todo" : capitalize(category);
      const activeClass = category === "all" ? "active" : "";
      return `<button class="chip ${activeClass}" data-category="${category}">${label}</button>`;
    })
    .join("");
}

function renderCards(items) {
  if (!items.length) {
    cardsGrid.innerHTML = "";
    emptyState.classList.remove("hidden");
    emptyState.classList.add("visible");
    return;
  }

  emptyState.classList.add("hidden");
  emptyState.classList.remove("visible");

  cardsGrid.innerHTML = items
    .map(
      (item) => `
        <article class="card">
          <img class="card__image" src="${item.image}" alt="Imagen representativa de ${item.title}">
          <div class="card__body">
            <div class="card__meta">
              <span>${capitalize(item.category)}</span>
              <span>${item.location}</span>
            </div>
            <h3>${item.title}</h3>
            <p>${item.description}</p>
            <div class="card__actions">
              <button class="card__button card__button--primary" data-action="details" data-id="${item.id}">Ver detalle</button>
              <button class="card__button card__button--ghost" data-action="highlight" data-id="${item.id}">Destacar</button>
            </div>
          </div>
        </article>
      `
    )
    .join("");
}

function applyFilters() {
  const filtered = catalog.filter((item) => {
    const matchesCategory = activeCategory === "all" || item.category === activeCategory;
    const matchesSearch = `${item.title} ${item.category} ${item.location}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  renderCards(filtered);
}

function setupEvents() {
  searchInput.addEventListener("input", (event) => {
    searchTerm = event.target.value.trim();
    applyFilters();
  });

  categoryFilter.addEventListener("change", (event) => {
    activeCategory = event.target.value;
    syncChips();
    applyFilters();
  });

  chipContainer.addEventListener("click", (event) => {
    const chip = event.target.closest("[data-category]");
    if (!chip) return;

    activeCategory = chip.dataset.category;
    categoryFilter.value = activeCategory;
    syncChips();
    applyFilters();
  });

  cardsGrid.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const id = Number(button.dataset.id);
    const action = button.dataset.action;
    const selectedItem = catalog.find((item) => item.id === id);

    if (!selectedItem) return;

    if (action === "details") {
      openDetails(selectedItem);
    }

    if (action === "highlight") {
      button.textContent = "Destacado";
      button.disabled = true;
      button.style.opacity = "0.7";
    }
  });

  closeModal.addEventListener("click", () => detailModal.close());

  navToggle.addEventListener("click", () => {
    mainNav.classList.toggle("open");
  });

  contactForm.addEventListener("submit", handleSubmit);
}

function syncChips() {
  document.querySelectorAll(".chip").forEach((chip) => {
    chip.classList.toggle("active", chip.dataset.category === activeCategory);
  });
}

function openDetails(item) {
  modalContent.innerHTML = `
    <img src="${item.image}" alt="Imagen de ${item.title}">
    <span class="eyebrow">${capitalize(item.category)} · ${item.location}</span>
    <h2>${item.title}</h2>
    <p>${item.description}</p>
    <div class="modal__tags">
      ${item.tags.map((tag) => `<span class="chip">#${tag}</span>`).join("")}
    </div>
    <p>
      Esta ventana modal es una función útil para demostrar manejo del DOM, inserción dinámica de contenido
      y mejora de experiencia visual.
    </p>
  `;

  detailModal.showModal();
}

function handleSubmit(event) {
  event.preventDefault();

  const formData = new FormData(contactForm);
  const payload = Object.fromEntries(formData.entries());
  const errors = validateForm(payload);

  clearErrors();

  if (Object.keys(errors).length > 0) {
    renderErrors(errors);
    formSuccess.classList.add("hidden");
    return;
  }

  formSuccess.classList.remove("hidden");
  console.log("Datos simulados del formulario:", payload);
  contactForm.reset();
}

function validateForm(data) {
  const errors = {};

  if (!data.name || data.name.trim().length < 4) {
    errors.name = "Escribe un nombre válido con al menos 4 caracteres.";
  }

  if (!/^\S+@\S+\.\S+$/.test(data.email || "")) {
    errors.email = "Ingresa un correo electrónico válido.";
  }

  if (!/^\d{10}$/.test((data.phone || "").trim())) {
    errors.phone = "El teléfono debe tener exactamente 10 dígitos.";
  }

  if (!data.interest) {
    errors.interest = "Selecciona una categoría de interés.";
  }

  if (!data.message || data.message.trim().length < 12) {
    errors.message = "El mensaje debe tener al menos 12 caracteres.";
  }

  return errors;
}

function clearErrors() {
  ["Name", "Email", "Phone", "Interest", "Message"].forEach((field) => {
    document.getElementById(`error${field}`).textContent = "";
  });
}

function renderErrors(errors) {
  Object.entries(errors).forEach(([field, message]) => {
    const targetId = `error${capitalize(field)}`;
    const target = document.getElementById(targetId);
    if (target) target.textContent = message;
  });
}

function animateCounters() {
  const counters = document.querySelectorAll("[data-counter]");

  counters.forEach((counter) => {
    const target = Number(counter.dataset.counter);
    let current = 0;
    const increment = Math.max(1, Math.ceil(target / 50));

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        counter.textContent = target;
        clearInterval(timer);
        return;
      }
      counter.textContent = current;
    }, 20);
  });
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

init();
